package com.example.crosshair;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    static final String ACTION_MOVE = "com.example.crosshair.MOVE";
    static final String ACTION_STOP = "com.example.crosshair.STOP";
    static final String CH = "crosshair";
    static final int[] COLORS = {Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.WHITE};

    WindowManager wm;
    NotificationManager nm;
    SharedPreferences sp;
    CrosshairView cross;
    WindowManager.LayoutParams cp, mp;
    View menu;
    TextView stepLabel;
    boolean menuShown = false;
    int step = 5, type, color;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Прицел", NotificationManager.IMPORTANCE_LOW));
        sp = getSharedPreferences("c", MODE_PRIVATE);
        type = sp.getInt("type", 1);
        color = sp.getInt("color", Color.RED);

        cross = new CrosshairView(this);
        cross.set(type, color);
        cp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        cp.gravity = Gravity.CENTER;
        cp.x = sp.getInt("x", 0);
        cp.y = sp.getInt("y", 0);
        wm.addView(cross, cp);

        // қолмен сүйреу (тек жылжыту режимінде жұмыс істейді)
        cross.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = cp.x; sy = cp.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        cp.x = sx + (int) (e.getRawX() - dx);
                        cp.y = sy + (int) (e.getRawY() - dy);
                        wm.updateViewLayout(cross, cp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        savePos(); return true;
                }
                return false;
            }
        });
        buildMenu();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, buildNotification());
        String a = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(a)) {
            stopForeground(true);
            stopSelf();
        } else if (ACTION_MOVE.equals(a)) {
            toggleMenu();
        }
        return START_STICKY;
    }

    // ---------- Хабарлама ----------
    Notification buildNotification() {
        PendingIntent mv = PendingIntent.getService(this, 1,
                new Intent(this, OverlayService.class).setAction(ACTION_MOVE),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent st = PendingIntent.getService(this, 2,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("Прицел қосулы")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_edit, menuShown ? "Жылжытуды жабу" : "Жылжыту", mv)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Өшіру", st)
                .build();
    }

    // ---------- Меню ----------
    void toggleMenu() {
        menuShown = !menuShown;
        if (menuShown) {
            wm.addView(menu, mp);
            cp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            wm.removeView(menu);
            cp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        wm.updateViewLayout(cross, cp);
        nm.notify(1, buildNotification()); // батырма мәтінін жаңарту
    }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    void buildMenu() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(6), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE222222);
        bg.setCornerRadius(dp(14));
        root.setBackground(bg);

        mp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        mp.gravity = Gravity.TOP | Gravity.START;
        mp.x = dp(16); mp.y = dp(120);

        // меню тақырыбы: осыдан сүйреп менюді жылжытуға болады
        TextView title = new TextView(this);
        title.setText("✥ Прицел (осыдан сүйреңіз)");
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(6), 0, dp(6));
        title.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = mp.x; sy = mp.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        mp.x = sx + (int) (e.getRawX() - dx);
                        mp.y = sy + (int) (e.getRawY() - dy);
                        wm.updateViewLayout(menu, mp);
                        return true;
                }
                return false;
            }
        });
        root.addView(title);

        // түрі
        LinearLayout r1 = row();
        r1.addView(btn("◀ Түрі", v -> { type = (type + CrosshairView.TYPES - 1) % CrosshairView.TYPES; apply(); }));
        r1.addView(btn("Түрі ▶", v -> { type = (type + 1) % CrosshairView.TYPES; apply(); }));
        root.addView(r1);

        // түсі
        LinearLayout r2 = row();
        for (int c : COLORS) {
            Button b = btn("", v -> { color = c; apply(); });
            b.setBackgroundColor(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
            lp.setMargins(dp(3), dp(6), dp(3), dp(6));
            r2.addView(b, lp);
        }
        root.addView(r2);

        // қадам
        stepLabel = new TextView(this);
        stepLabel.setTextColor(Color.WHITE);
        stepLabel.setGravity(Gravity.CENTER);
        stepLabel.setText("Қадам: " + step + " px");
        root.addView(stepLabel);
        LinearLayout r3 = row();
        for (int s : new int[]{1, 5, 10, 25}) {
            r3.addView(btn(String.valueOf(s), v -> { step = s; stepLabel.setText("Қадам: " + step + " px"); }));
        }
        root.addView(r3);

        // бағыттар
        LinearLayout up = row();
        up.addView(btn("▲", v -> move(0, -step)));
        LinearLayout mid = row();
        mid.addView(btn("◀", v -> move(-step, 0)));
        mid.addView(btn("▼", v -> move(0, step)));
        mid.addView(btn("▶", v -> move(step, 0)));
        root.addView(up);
        root.addView(mid);

        root.addView(btn("Орталыққа қайтару", v -> { cp.x = 0; cp.y = 0; wm.updateViewLayout(cross, cp); savePos(); }));
        menu = root;
    }

    void move(int dx, int dy) {
        cp.x += dx; cp.y += dy;
        wm.updateViewLayout(cross, cp);
        savePos();
    }

    void apply() {
        cross.set(type, color);
        sp.edit().putInt("type", type).putInt("color", color).apply();
    }

    void savePos() { sp.edit().putInt("x", cp.x).putInt("y", cp.y).apply(); }

    @Override
    public void onDestroy() {
        try { wm.removeView(cross); } catch (Exception ignored) {}
        if (menuShown) { try { wm.removeView(menu); } catch (Exception ignored) {} }
        super.onDestroy();
    }
}
