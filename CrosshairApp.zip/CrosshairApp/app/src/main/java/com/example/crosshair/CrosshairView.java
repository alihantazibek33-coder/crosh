package com.example.crosshair;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class CrosshairView extends View {
    public static final int TYPES = 5;
    private int type = 1, color = Color.RED;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public CrosshairView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    public void set(int t, int col) { type = t; color = col; invalidate(); }

    @Override
    protected void onMeasure(int w, int h) {
        int s = (int) (120 * d);
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float g = 6 * d, l = 28 * d, r = 30 * d;
        p.setColor(color);
        p.setStrokeWidth(2 * d);
        switch (type) {
            case 0: // нүкте
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, 4 * d, p);
                break;
            case 1: // крест (ортасы бос)
                c.drawLine(cx - l, cy, cx - g, cy, p);
                c.drawLine(cx + g, cy, cx + l, cy, p);
                c.drawLine(cx, cy - l, cx, cy - g, p);
                c.drawLine(cx, cy + g, cx, cy + l, p);
                break;
            case 2: // шеңбер
                p.setStyle(Paint.Style.STROKE);
                c.drawCircle(cx, cy, r, p);
                break;
            case 3: // шеңбер + нүкте
                p.setStyle(Paint.Style.STROKE);
                c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, 3 * d, p);
                break;
            case 4: // X
                c.drawLine(cx - l, cy - l, cx - g, cy - g, p);
                c.drawLine(cx + g, cy + g, cx + l, cy + l, p);
                c.drawLine(cx + l, cy - l, cx + g, cy - g, p);
                c.drawLine(cx - g, cy + g, cx - l, cy + l, p);
                break;
        }
    }
}
